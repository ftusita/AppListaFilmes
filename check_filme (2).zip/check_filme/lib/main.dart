import 'package:check_filme/constants.dart';
import 'package:check_filme/filme.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(ListaFilme());
}

class ListaFilme extends StatefulWidget {
  const ListaFilme({Key? key}) : super(key: key);

  @override
  State<ListaFilme> createState() => _ListaFilmeState();
}

class _ListaFilmeState extends State<ListaFilme> {
  int _selectedIndex = 0; // Índice da tela selecionada
  final List<Filme> filmes = [
    Filme('Duna 2', '2024',  false, 'images/dune2.jpg'),
    Filme('John Wick 4', '2023', false, 'images/johnwick.jpg'),
    Filme('Oppenheimer', '2023',  false, 'images/open.jpg'),
    Filme('Homem-Aranha: No way home ', '2022', false,'images/noway.jpg'),
    Filme('The Batman', '2022',  false,'images/TheBat.jpg'),
    Filme('Finch', '2021',  false,'images/Finch.jpg'),
    Filme('A Quiet Place Part 2', '2021',  false,'images/Quiet.jpg'),
    Filme('Tenet', '2020', false,'images/tenet.jpg'),
    Filme('Star Wars: episódio IX', '2019',  false,'images/star.jpg'),
    Filme('Vingadores: Ultimato ', '2019',  false,'images/avengers.jpg'),
    Filme('Maze Runner: A cura mortal', '2018', false,'images/Maze.jpg'),
    Filme('Dunkirk', '2017',  false,'images/dunkirk.jpg'),
    Filme('Blade Runner 2043','2017', false,'images/Blade.jpg'),
    Filme('A Chegada', '2016',  false,'images/chegada.jpg'),
    Filme('Interestelar','2014', false,'images/Inter.png'),
    Filme('O Lobo de Wall Street', '2013', false,'images/wolf.jpg'),
  ];

  // Lista de filmes filtrados
  List<Filme> filmesFiltrados = [];

  // Lista de filmes favoritos
  List<Filme> filmesFavoritos = [];

  // Função para atualizar o índice selecionado ao clicar nos itens da barra de navegação
  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  // Função para buscar o filme com base no nome
  void _buscarFilme(String nomeFilme) {
    setState(() {
      filmesFiltrados.clear();
      for (var filme in filmes) {
        if (filme.nome.toLowerCase().contains(nomeFilme.toLowerCase())) {
          filmesFiltrados.add(filme);
        }
      }
    });
  }

  // Método para redirecionar para a página inicial (Home)
  void _redirecionarParaHome() {
    setState(() {
      _selectedIndex = 0;
    });
  }

  // Widget da tela de filmes
  Widget _buildHomeScreen() {
    return ListView.builder(
      itemCount: filmesFiltrados.isNotEmpty ? filmesFiltrados.length : filmes.length,
      itemBuilder: (BuildContext context, int index) {
      // String firstLetter = filmesFiltrados.isNotEmpty ? filmesFiltrados[index].nome[0].toUpperCase() : filmes[index].nome[0].toUpperCase();

        return ListTile(
          leading: Image.asset(
            (filmes[index].image),
          ),
          title: Text(filmesFiltrados.isNotEmpty ? filmesFiltrados[index].nome : filmes[index].nome),
          subtitle: Text(filmesFiltrados.isNotEmpty ? filmesFiltrados[index].ano : filmes[index].ano),
          trailing: IconButton(
            icon: Icon(
              filmesFiltrados.isNotEmpty
                  ? filmesFiltrados[index].favorito ? Icons.star : Icons.star_border
                  : filmes[index].favorito ? Icons.star : Icons.star_border,
              color: filmesFiltrados.isNotEmpty
                  ? filmesFiltrados[index].favorito ? Colors.yellow : null
                  : filmes[index].favorito ? Colors.yellow : null,
            ),
            onPressed: () {
              setState(() {
                filmes[index].favorito = !filmes[index].favorito;
                if (filmes[index].favorito) {
                  filmesFavoritos.add(filmes[index]);
                } else {
                  filmesFavoritos.remove(filmes[index]);
                }
              });
            },
          ),
        );
      },
    );
  }

  // Widget da tela de busca
  Widget _buildSearchScreen(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(20.0),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          TextField(
            onChanged: (value) {
              _buscarFilme(value);
            },
            decoration: InputDecoration(
              labelText: 'Digite o nome do filme',
              border: OutlineInputBorder(),
            ),
          ),
          SizedBox(height: 20),
          ElevatedButton(
            onPressed: _redirecionarParaHome, // Redirecionar para a Home ao pressionar o botão
            child: Text('Buscar'),
          ),
        ],
      ),
    );
  }

  // Widget da tela de perfil
  Widget _buildProfileScreen() {
        return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          CircleAvatar(
            radius: 50,
            backgroundColor: Colors.blue,
            child: Icon(
              Icons.person,
              size: 60,
              color: Colors.white,
            
            ),
          ),
          SizedBox(height: 20),
          Text(
            'Felipe',
            style: TextStyle(fontSize: 24),
          ),
          SizedBox(height: 20),
          Text(
            'Filmes favoritos: ${filmesFavoritos.length}',
            style: TextStyle(fontSize: 18),
          ),
          SizedBox(height: 20),
          ListView.builder(
            shrinkWrap: true,
            itemCount: filmesFavoritos.length,
            itemBuilder: (context, index) {
              return ListTile(
                title: Text(filmesFavoritos[index].nome),
                trailing: IconButton(
                  icon: Icon(Icons.star),
                  onPressed: () {
                    setState(() {
                      filmesFavoritos[index].favorito = false;
                      filmesFavoritos.removeAt(index);
                    });
                  },
                ),
              );
            },
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'MyMovies',
      theme: ThemeData.dark().copyWith(
          primaryColor: backgroundColor,
          scaffoldBackgroundColor: backgroundColor,
          appBarTheme: const AppBarTheme().copyWith(
            backgroundColor: backgroundColor,
          )
      ) ,
      home: Scaffold(
        appBar: AppBar(
          title: const Text('MyMovies', style: TextStyle(fontSize: 30, color: Colors.yellow,),),
          centerTitle: true,
        ),
        bottomNavigationBar: BottomNavigationBar(
          backgroundColor: Colors.black,
          items: const <BottomNavigationBarItem>[
            BottomNavigationBarItem(
              icon: Icon(Icons.home),
              label: 'Home',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.search),
              label: 'Buscar',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.person),
              label: 'Perfil',
            ),
          ],
          currentIndex: _selectedIndex,
          selectedItemColor: Colors.blue,
          onTap: _onItemTapped,
        ),
        body: Center(
          child: _selectedIndex == 0
              ? _buildHomeScreen()
              : _selectedIndex == 1
              ? _buildSearchScreen(context)
              : _buildProfileScreen(),
        ),
      ),
    );
  }
}
