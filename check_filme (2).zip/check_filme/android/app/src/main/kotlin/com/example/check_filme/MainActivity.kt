package com.example.check_filme

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
