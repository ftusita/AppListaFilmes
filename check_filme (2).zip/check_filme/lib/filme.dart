
class Filme {
String nome;
String ano;
bool favorito;
String image;



Filme(this.nome, this.ano,this.favorito, this.image);


}